<!---

Add the issue number that is discussed and fixed by this PR (In the form
`Closes #123`). If this PR doesn't fix an issue, remove the line below. This will
also lead to us not treating this PR as an important one. It might be closed
without a review.

If there is no issue associated with this PR and you are not a maintainer of
this repository, your PR might be closed without a review.

-->

Closes ####

<!---

Explain what this PR does and what existing problem it solves. If this PR is a
work in progress, please prefix the title with [WIP].

-->

<!--

Make sure that the code is readable and well-documented. If you have added new
functionality, please add the necessary documentation.
If testing of the new functionality is possible, please add tests.

-->
